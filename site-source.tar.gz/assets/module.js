
import {Client,TablesDB,Query,Storage} from "https://cdn.jsdelivr.net/npm/appwrite@29.3.0/+esm";
const cfg=window.APP_CONFIG||{}, id=Number(new URLSearchParams(location.search).get("id"));
const modules=await(await fetch("modules.json")).json(), m=modules.find(x=>x.id===id);
const title=document.getElementById("title"), desc=document.getElementById("desc"), host=document.getElementById("module-content");
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
if(!m){title.textContent="মডিউল পাওয়া যায়নি";host.textContent="সঠিক মডিউল নির্বাচন করুন।"}
else{
 title.textContent=m.title;desc.textContent=m.description;document.title=m.title+" | শায়লা আকরাম";
 if(cfg.projectId&&!cfg.projectId.startsWith("YOUR_"))try{
  const db=new TablesDB(new Client().setEndpoint(cfg.endpoint).setProject(cfg.projectId));
  const result=await db.listRows({databaseId:cfg.databaseId,tableId:cfg.contentTableId,queries:[Query.equal("moduleId",id),Query.equal("published",true),Query.orderDesc("$createdAt"),Query.limit(50)]});
  if(result.rows.length){const storage=new Storage(new Client().setEndpoint(cfg.endpoint).setProject(cfg.projectId));host.innerHTML=result.rows.map(r=>{let media="";if(r.mediaFileId){const url=storage.getFileView({bucketId:cfg.storageBucketId,fileId:r.mediaFileId});media=r.mediaType==="video"?`<video controls playsinline style="width:100%;max-height:520px;border-radius:18px" src="${url}"></video>`:`<img loading="lazy" style="width:100%;max-height:520px;object-fit:contain;border-radius:18px" src="${url}" alt="${esc(r.title)}">`}return `<article class="adminbox"><span class="pill">${new Date(r.$createdAt).toLocaleDateString("bn-BD")}</span><h2>${esc(r.title)}</h2>${media}<div style="white-space:pre-wrap;line-height:1.9;margin-top:12px">${esc(r.body)}</div></article>`}).join("")}
  else host.innerHTML='<div class="notice">এই বিভাগে এখনো কোনো তথ্য প্রকাশ করা হয়নি।</div>';
 }catch(e){host.innerHTML='<div class="notice">তথ্য লোড করা যায়নি। Appwrite-এর public read permission ও configuration যাচাই করুন।</div>'}
}
