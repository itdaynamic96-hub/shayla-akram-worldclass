// নতুন Appwrite project-এর মান এখানে বসান। পুরোনো মসজিদ প্রকল্পের ID ব্যবহার করবেন না।
window.APP_CONFIG = {
  endpoint: "https://YOUR_REGION.cloud.appwrite.io/v1",
  projectId: "YOUR_NEW_PROJECT_ID",
  databaseId: "YOUR_NEW_DATABASE_ID",
  contentTableId: "site_content",
  prayerTableId: "prayer_times",
  applicationsTableId: "applications",
  volunteersTableId: "volunteers",
  accountsTableId: "account_entries",
  storageBucketId: "YOUR_NEW_BUCKET_ID",
  adminTeamId: "YOUR_NEW_ADMIN_TEAM_ID",
  intakeFunctionUrl: "YOUR_APPWRITE_FUNCTION_EXECUTION_URL"
};
