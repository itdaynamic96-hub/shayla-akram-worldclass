
import { Client, TablesDB, Query, Storage } from "https://cdn.jsdelivr.net/npm/appwrite@29.3.0/+esm";
const cfg=window.APP_CONFIG||{};
const configured=cfg.projectId && !cfg.projectId.startsWith("YOUR_");
const modules=await (await fetch("modules.json")).json();
const icons=["◈","✧","◷","☼","◉","☾","♙","♧","▤","✦","▧","▷","▤","۞","⌖","✎","◇","◎","♡","✧","✚","♧","♙","◫","⌂"];
const card=(m,i)=>`<a class="card" href="module.html?id=${m.id}"><span class="card-icon">${icons[i%icons.length]}</span><h3>${m.title}</h3><p>${m.description}</p><span class="more">বিস্তারিত দেখুন ↗</span></a>`;
document.getElementById("mosque-modules").innerHTML=modules.filter(m=>m.group==="mosque").map((m,i)=>card(m,i)).join("");
document.getElementById("foundation-modules-grid").innerHTML=modules.filter(m=>m.group==="foundation").map((m,i)=>card(m,i+16)).join("");
document.getElementById("menubtn")?.addEventListener("click",()=>document.getElementById("navlinks").classList.toggle("open"));
if(configured){
  try{
    const client=new Client().setEndpoint(cfg.endpoint).setProject(cfg.projectId);
    const db=new TablesDB(client);
    const rows=await db.listRows({databaseId:cfg.databaseId,tableId:cfg.contentTableId,queries:[Query.equal("published",true),Query.orderDesc("$createdAt"),Query.limit(8)]});
    const target=document.getElementById("latest-list");
    if(target && rows.rows.length){
      target.innerHTML=rows.rows.map(row=>{
        const m=modules.find(x=>x.id===Number(row.moduleId));
        return `<a class="notice" href="module.html?id=${row.moduleId}"><b>${escapeHtml(row.title||m?.title||"প্রকাশনা")}</b><div>${escapeHtml((row.summary||row.body||"").slice(0,170))}</div><small>${escapeHtml(m?.title||"প্রকাশনা")} · ${new Date(row.$createdAt).toLocaleDateString("bn-BD")}</small></a>`;
      }).join("");
    }
    const prayers=await db.listRows({databaseId:cfg.databaseId,tableId:cfg.prayerTableId,queries:[Query.orderDesc("dateKey"),Query.limit(1)]});
    if(prayers.rows[0]){
      const p=prayers.rows[0];const names=["fajr","dhuhr","asr","maghrib","isha","jumuah"];
      document.querySelectorAll("[data-prayer]").forEach(el=>{const key=el.dataset.prayer;if(p[key])el.textContent=p[key]});
      const date=document.getElementById("prayer-date");if(date)date.textContent=p.dateKey||"";
    }
  }catch(e){console.warn("Public content is not configured or not readable yet.",e)}
}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
